This repository contains some sample scripts that will help you getting started with your machine learning project. *Don't use this repository for your project, create a dedicated repository in your GitLab team group for that.*

# Technologies and Terms

* we use the **[MediaPipe](https://google.github.io/mediapipe/)** framework to retrieve human body keypoints from videos
* you can use the python web server **Sanic** to serve **[Reveal.js](http://revealjs.com)** slideshows and trigger actions with **events** via **web sockets**
* you can use the free software **[ELAN](https://tla.mpi.nl/tools/tla-tools/elan/)** to annotate your own videos; export the annotations as txt files so you can read them with your Python scripts

# Prerequesites

 * you need Python 3.7  (or higher)

# Setup
1. Open your terminal
2. Switch to this directory
3. Install dependencies listed in `requirements.txt`, for example with `pip install -r requirements.txt`

# Examples

Open a terminal to run the example scripts.

## Process Videos `process_videos/`

### `live_video_feed.py`: Example for live pose detection - a good way to test if MediaPipe installation is working on your machine!

Have a look at `live_video_feed.py`. It demonstrates how you can use MediaPipe to get the coordinates of human body keypoints, either directly from a webcam or from a video:

    python live_video_feed.py

### `video_to_csv.py`: Extract data from video

If you'd like to extract the keypoint coordinates from a video file and save the data for later processing (i.e., to train your model), have a look at `video_to_csv.py`: the script receives a video and writes the keypoint coordinates to a CSV file. This script is somewhat an extension of "live_video_feed.py".

    python video_to_csv.py

### `examples_and_elan_annotations.ipynb`: Examples for what you can do with the data

You've already labeled your videos with the annotation tool "ELAN" and have extracted the keypoint coordinates with `video_to_csv.py`. What now? You need to somehow combine these data so your training routine can use it to train your machine learning models. In this notebook you will find examples how you can leverage pandas to do exactly that: read the CSV files and the exported files from ELAN to combine data and labels.

To open the Jupyter Notebook `examples_and_elan_annotations.ipynb`:

  1. run a jupyter server
  2. open the notebook

Make sure to understand anything that happens in that notebook! It contains techniques you most certainly will require for your own implementations.

## Performance Score `performance_score/`

### `log_emitted_events_to_csv.py`: Produce the CSV for the performance scoring

In the exam the performance of your model will be evaluated. For this you'll be provided two CSV video transcriptions (such as `demo_data/demo_video_frames.csv`) that we've created with `video_to_csv.py`. You have to provide a script that reads this CSV-file and produces a new CSV file containing a column `events` that contains the events your application registers for each frame. Have a look into `demo_data/demo_video_events_rotate.csv` for an example that would score 100% for the "demo_video".

You can use the script like this:
    python performance_score/log_emitted_events_to_csv.py --input_csv=demo_data/demo_video_frames_rotate.csv

This creates a new CSV file (named `emitted_events.csv` by default) and logs an event for each frame (randomly in its current version for demonstration purposes). On the examination date we will compare this CSV file to the ground truth (that only we have) and calculate your score based on that (see next section). The column "events" should contain the name of the detected gesture as string (e.g., "swipe_left" or "idle"). For a full list and exact names of all the possible gestures of the mandatory requirements refer to the requirements document in the WueCampus course.

### `calculator.py`: Compute the performance score for grading

In the final exam a script like `performance_score_calculator.py` will be used to determine the performance score (see the final project requirements in WueCampus). Inspect `performance_score/calculator.py` to verify how the score will be determined. We suggest you create your own test videos and compute the performance score on them to evaluate your model. 

#### Prerequisites

The script requires two inputs:

1. a CSV file with **the events** from your application: use `performance_score/log_emitted_events_to_csv.py` as described above to get `emitted_events.csv`; you can also check out `demo_data/demo_video_events_rotate.csv` which is an example for an output that would score 100% on the "demo_video"
2. a CSV file with **the ground truth**: you need a corresponding CSV file for the `emitted_events.csv` where each frame is labeled with the ground truth (column named `ground_truth`). `process_videos/data_examples.ipynb` produces such a CSV file and saves it to `demo_data/demo_video_csv_with_ground_truth_rotate.csv`, so simply execute the notebook to get an example file

#### Run

Call the script like this:

    python performance_score/calculator.py --events_csv=demo_data/emitted_events.csv --ground_truth_csv=demo_data/demo_video_csv_with_ground_truth_rotate.csv


And here the same with an output that would achieve the full score:

    python performance_score/calculator.py --events_csv=demo_data/demo_video_events_rotate.csv --ground_truth_csv=demo_data/demo_video_csv_with_ground_truth_rotate.csv

### `events_visualization.py`: A helper to visually compare the output of your model with the ground truth

This is a small helper script supposed to help you comparing the output of your model with the ground truth. You can call it like `calculator.py`:

    python performance_score/events_visualization.py --events_csv=demo_data/demo_video_events_rotate.csv --ground_truth_csv=demo_data/demo_video_csv_with_ground_truth_rotate.csv

This will open an image of the timeline of your video, with each pixel row representing one frame, and a column for each gesture. Gestures are highlighted with green areas, while the events emitted by your model are marked by yellow lines. Addtionally, the image is saved as "events_visualization.png" to your disk. This can help you to figure out why, for example, your model is getting a bad score from the `calculator.py`.

#### Notes

* `--predictions_csv` and `--ground_truth_csv` may point to the same file as long as it contains one column `events` with your application's events and another column `ground_truth` with the ground truth


## Demo Slideshow `slideshow/slideshow_demo.py`

This script starts a small web server which serves an HTML-slideshow. The script also includes the logic you'll need to send events from Python to the webpage in order to control the slideshow.

The script uses the python web server *Sanic* to run [reveal.js](https://github.com/hakimel/reveal.js). It also contains examples for how you can trigger events that are listened to by the HTML page (have a look into `slideshow/slideshow.html` and `slideshow/event_listeners.js`)

#### Run

1. run the server with `python slideshow_demo.py`
2. open a web browser and visit http://localhost:8000
3. you can use ctrl-c to kill the server
4. familiarize yourself with the slideshow and what controls it has
    * you can use your keyboard to jump to the next/previous slide or go up and down
    * hit `?` to open up the help and check out what else you can do (like go fullscreen, open the speaker notes, etc.) – you can later map these controls to your additional gestures
5. uncomment the code block in `slideshow_demo.py`, restart the web server (`ctrl-c` and execute the script again), and switch to the browser again. Observe what happens.

#### Notes

* you can control the slideshow from Python by emitting events with `await sio.emit("<event_name>")`
* to make the HTML slideshow listen and react to additional events check out `slideshow/event_listeners.js`
* you can interact with the HTML slideshow in JavaScript using the `Reveal` object (for examples have a look into `slideshow/event_listeners.js`). Refer to the [Reveal.js documentation](https://github.com/hakimel/reveal.js#api) for all actions you can make the slideshow do for you
* you can see JavaScript messages sent with `console.log()` in your browser's developer console ("Entwicklertools") – ask Google for instructions how you can open it in your browser
* you can change the slides defined in `slideshow/slideshow.html` to your liking; again, if you want to know how Reveal.js slideshows are defined, visit the [documentation](https://github.com/hakimel/reveal.js#instructions)

#### Async Notes – don't get blocked!

The script runs two routines pseudo-asynchronously: 1) the Sanic web server and 2) your model and event-emitter routine (represented by the `emitter()` function in `slideshow_demo.py`). The gotcha: the Python interpreters can only execute one routine at a time. You can ensure that your two routines can co-exist by putting a `await asyncio.sleep(0.001)` in your `while`-loop. This pauses your prediction/emitter routine for 0.001 seconds and allows the web server routine to run for a bit. There may be more elegant solutions, but this should do the trick.
